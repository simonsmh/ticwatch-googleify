#!/bin/sh

# delete.sh

rm /system/etc/sysconfig/cn_google_features.xml
rm -rf /system/priv-app/PrebuiltWearskyHeadless
rm -rf /system/priv-app/WearPinyinKeyboard